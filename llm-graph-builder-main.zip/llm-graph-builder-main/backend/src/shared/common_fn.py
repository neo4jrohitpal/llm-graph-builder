import hashlib
import ipaddress
import os
import json
import logging
import socket
from typing import Any
import requests
from src.entities.user_credential import Neo4jCredentials
from threading import Lock
from urllib.parse import urlparse,parse_qs
from src.shared.llm_graph_builder_exception import LLMGraphBuilderException
from langchain_ollama import OllamaEmbeddings
from langchain_neo4j import Neo4jGraph
from neo4j.exceptions import TransientError
from langchain_community.graphs.graph_document import GraphDocument
from typing import List
import re
import time
from pathlib import Path
from langchain_core.callbacks import BaseCallbackHandler


# --- Embedding Model Helpers ---
_embedding_instances = {}
_embedding_locks = {}


def _get_ollama_embeddings(model_name: str):
    """Return a thread-safe singleton for the configured Ollama embedding model."""
    base_url = get_value_from_env("OLLAMA_BASE_URL", "http://localhost:11434")
    cache_key = f"{base_url}/{model_name}"
    if cache_key not in _embedding_locks:
        _embedding_locks[cache_key] = Lock()
    if cache_key in _embedding_instances:
        return _embedding_instances[cache_key]
    with _embedding_locks[cache_key]:
        if cache_key not in _embedding_instances:
            _embedding_instances[cache_key] = OllamaEmbeddings(
                model=model_name,
                base_url=base_url,
            )
            logging.info(
                "Ollama embedding model %s initialized at %s.",
                model_name,
                base_url,
            )
    return _embedding_instances[cache_key]
   
# --- SSRF Guard Helpers ---
_SSRF_MAX_REDIRECTS = 5


def is_public_ip(ip_str: str) -> bool:
    """Returns False for private, loopback, link-local, multicast, reserved or unspecified IPs."""
    ip = ipaddress.ip_address(ip_str)
    return not (
        ip.is_private
        or ip.is_loopback
        or ip.is_link_local
        or ip.is_multicast
        or ip.is_reserved
        or ip.is_unspecified
    )

def assert_public_http_url(url: str):
    """
    Guards against SSRF: ensures the URL is http(s) and every IP it resolves to
    is a public address (blocks internal services, cloud metadata endpoints, etc).
    Raises ValueError if the URL is unsafe.
    """
    p = urlparse(url)
    if p.scheme not in ("http", "https"):
        raise ValueError("Only http(s) URLs are allowed")
    if not p.hostname:
        raise ValueError("URL is missing a hostname")
    try:
        addrinfo = socket.getaddrinfo(p.hostname, None)
    except socket.gaierror as exc:
        raise ValueError(f"Unable to resolve host: {p.hostname}") from exc
    resolved_ips = {sockaddr[0] for _, _, _, _, sockaddr in addrinfo}
    if not resolved_ips or not all(is_public_ip(ip) for ip in resolved_ips):
        raise ValueError(f"Access to internal addresses is blocked: {p.hostname}")


def fetch_public_url(url: str, session: requests.Session = None, max_redirects: int = _SSRF_MAX_REDIRECTS, **kwargs):
    """
    Safely GETs a URL while guarding against SSRF, including via redirects:
    validates the URL (and every redirect hop) resolves only to public IP
    addresses before following it.

    Returns:
        tuple: (requests.Response, final_url)
    """
    session = session or requests
    current_url = url
    for _ in range(max_redirects + 1):
        assert_public_http_url(current_url)
        response = session.get(current_url, allow_redirects=False, **kwargs)
        if response.is_redirect or response.is_permanent_redirect:
            next_url = response.headers.get('Location')
            if not next_url:
                return response, current_url
            current_url = requests.compat.urljoin(current_url, next_url)
            continue
        return response, current_url
    raise ValueError("Too many redirects")


def create_youtube_url(url):
    you_tu_url = "https://www.youtube.com/watch?v="
    u_pars = urlparse(url)
    quer_v = parse_qs(u_pars.query).get('v')
    if quer_v:
      return  you_tu_url + quer_v[0].strip()

    pth = u_pars.path.split('/')
    if pth:
      return you_tu_url + pth[-1].strip()

def check_url_source(source_type, yt_url:str=None, wiki_query:str=None):
    language=''
    try:
      logging.info(f"incoming URL: {yt_url}")
      if source_type == 'youtube':
        if re.match(r'(?:https?:\/\/)?(?:www\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed|shorts)?(?:.*v=|v\/|\/)([\w\-_]+)\&?',yt_url.strip()):
          youtube_url = create_youtube_url(yt_url.strip())
          logging.info(youtube_url)
          return youtube_url,language
        else:
          raise Exception('Incoming URL is not youtube URL')
      
      elif  source_type == 'Wikipedia':
        wiki_query_id=''

        wikipedia_url_regex = r'https?:\/\/(www\.)?([a-zA-Z]{2,3})\.wikipedia\.org\/wiki\/(.*)'
        
        match = re.search(wikipedia_url_regex, wiki_query.strip())
        if match:
                language = match.group(2)
                wiki_query_id = match.group(3).split('#')[0]
        else:
            raise Exception(f'Not a valid wikipedia url: {wiki_query} ')

        logging.info(f"wikipedia query id = {wiki_query_id}")     
        return wiki_query_id, language     
    except Exception as e:
      logging.error(f"Error in recognize URL: {e}")
      raise Exception(e)


def get_chunk_and_graphDocument(graph_document_list, chunkId_chunkDoc_list):
  logging.info("creating list of chunks and graph documents in get_chunk_and_graphDocument func")
  lst_chunk_chunkId_document=[]
  for graph_document in graph_document_list:            
          for chunk_id in graph_document.source.metadata['combined_chunk_ids'] :
            lst_chunk_chunkId_document.append({'graph_doc':graph_document,'chunk_id':chunk_id})
                  
  return lst_chunk_chunkId_document  
                 
def create_graph_database_connection(credentials):
    graph = Neo4jGraph(url=credentials.uri, database=credentials.database, username=credentials.userName, password=credentials.password, refresh_schema=False, sanitize=True)    
    return graph



def load_embedding_model(embedding_provider: str, embedding_model_name: str):
    """
    Load the appropriate embedding model and return its instance and dimension.

    Args:
        embedding_provider (str): Must be "ollama".
        embedding_model_name (str): The specific model name.

    Returns:
        tuple: (embedding_instance, dimension)

    Raises:
        ValueError: If provider or model is not supported.
    """
    model_dimensions = {
        "ollama": {
            "nomic-embed-text": 768,
        },
    }

    provider = embedding_provider.lower()
    model = embedding_model_name

    if provider not in model_dimensions or model not in model_dimensions[provider]:
        raise ValueError(f"Unsupported provider/model: {provider}/{model}")

    dimension = model_dimensions[provider][model]

    embeddings = _get_ollama_embeddings(model)

    logging.info(f"Embedding: Using {provider} - {model}, Dimension: {dimension}")
    return embeddings, dimension

def save_graphDocuments_in_neo4j(graph: Neo4jGraph, graph_document_list: List[GraphDocument], max_retries=3, delay=1):
   retries = 0
   while retries < max_retries:
       try:
           graph.add_graph_documents(graph_document_list, baseEntityLabel=True)
           return
       except TransientError as e:
           if "DeadlockDetected" in str(e):
               retries += 1
               logging.info(f"Deadlock detected. Retrying {retries}/{max_retries} in {delay} seconds...")
               time.sleep(delay)  # Wait before retrying
           else:
               raise
   logging.error("Failed to execute query after maximum retries due to persistent deadlocks.")
   raise RuntimeError("Query execution failed after multiple retries due to deadlock.")
           
def handle_backticks_nodes_relationship_id_type(graph_document_list:List[GraphDocument]):
  for graph_document in graph_document_list:
    # Clean node id and types
    cleaned_nodes = []
    for node in graph_document.nodes:
      node_type = str(node.type).strip() if node.type is not None else ""
      node_id = str(node.id).strip() if node.id is not None else ""
      if node_type and node_id:
        node.type = node_type.replace('`', '')
        node.id = node_id
        cleaned_nodes.append(node)
    # Clean relationship id types and source/target node id and types
    cleaned_relationships = []
    for rel in graph_document.relationships:
      # Defensive checks for source/target presence
      src = getattr(rel, "source", None)
      tgt = getattr(rel, "target", None)
      rel_type = str(rel.type).strip() if rel.type is not None else ""
      src_type = str(getattr(src, "type", "")).strip() if src is not None else ""
      src_id = str(getattr(src, "id", "")).strip() if src is not None else ""
      tgt_type = str(getattr(tgt, "type", "")).strip() if tgt is not None else ""
      tgt_id = str(getattr(tgt, "id", "")).strip() if tgt is not None else ""
      if rel_type and src_id and src_type and tgt_id and tgt_type:
        rel.type = rel_type.replace('`', '')
        if src is not None:
          src.type = src_type.replace('`', '')
          src.id = src_id.replace('`', '')
        if tgt is not None:
          tgt.type = tgt_type.replace('`', '')
          tgt.id = tgt_id
        cleaned_relationships.append(rel)
    graph_document.relationships = cleaned_relationships
    graph_document.nodes = cleaned_nodes
  return graph_document_list

def execute_graph_query(graph: Neo4jGraph, query, params=None, max_retries=3, delay=2):
   retries = 0
   while retries < max_retries:
       try:
           return graph.query(query, params) 
       except TransientError as e:
           if "DeadlockDetected" in str(e):
               retries += 1
               logging.info(f"Deadlock detected. Retrying {retries}/{max_retries} in {delay} seconds...")
               time.sleep(delay)  # Wait before retrying
           else:
               raise 
   logging.error("Failed to execute query after maximum retries due to persistent deadlocks.")
   raise RuntimeError("Query execution failed after multiple retries due to deadlock.")

def delete_uploaded_local_file(merged_file_path, file_name):
  file_path = Path(merged_file_path)
  if file_path.exists():
    file_path.unlink()
    logging.info(f'file {file_name} deleted successfully')
   
def close_db_connection(graph, api_name):
  if not graph._driver._closed:
      logging.info(f"closing connection for {api_name} api")
      # graph._driver.close()   
  
def create_gcs_bucket_folder_name_hashed(uri, file_name):
  folder_name = uri + file_name
  folder_name_sha1 = hashlib.sha1(folder_name.encode())
  folder_name_sha1_hashed = folder_name_sha1.hexdigest()
  return folder_name_sha1_hashed

def formatted_time(current_time):
  formatted_time = current_time.strftime('%Y-%m-%d %H:%M:%S %Z')
  return str(formatted_time)

def last_url_segment(url):
  parsed_url = urlparse(url)
  path = parsed_url.path.strip("/")  # Remove leading and trailing slashes
  last_url_segment = path.split("/")[-1] if path else parsed_url.netloc.split(".")[0]
  return last_url_segment


   
def get_value_from_env(key_name: str, default_value: Any = None, data_type: type = str):
  
  value = os.getenv(key_name, None)
  if value is not None and value != '':
    return convert_type(value, data_type)
  elif default_value is not None:
    return convert_type(default_value, data_type)
  else:
    error_msg = f"Environment variable '{key_name}' not found and no default value provided."
    logging.error(error_msg)
    return None


def convert_type(value: str, data_type: type):
    """Convert value to the specified data type."""
    try:
        if data_type in (int, "int"):
            return int(value)
        elif data_type in (float, "float"):
            return float(value)
        elif data_type in (bool, "bool"):
            if isinstance(value, bool):
                return value
            if isinstance(value, (int, float)):
                return bool(value)
            if isinstance(value, str):
                return value.strip().lower() in ["true", "1", "yes"]
            raise ValueError(f"Cannot convert {value!r} to bool")
        elif data_type in (list, dict, "list", "dict"):
            return json.loads(value)
        elif data_type in (str, "str"):
            return str(value)
        else:
            raise TypeError(f"Unsupported data type for conversion: {data_type}")
    except Exception as e:
        logging.error(f"Type conversion error: {e}")
        raise


class UniversalTokenUsageHandler(BaseCallbackHandler):
    def __init__(self):
        self.total_prompt_tokens = 0
        self.total_completion_tokens = 0

    def on_llm_end(self, response, **kwargs):
        usage = response.llm_output.get("token_usage") if response.llm_output else None
       
        if usage:
            self.total_prompt_tokens += usage.get("prompt_tokens") or usage.get("input_tokens") or 0
            self.total_completion_tokens += usage.get("completion_tokens") or usage.get("output_tokens") or 0
            return

        for generations in response.generations:
            for generation in generations:
                if hasattr(generation, 'message'):
                    metadata = getattr(generation.message, 'usage_metadata', {})
                    if metadata:
                        self.total_prompt_tokens += metadata.get("input_tokens", 0)
                        self.total_completion_tokens += metadata.get("output_tokens", 0)

    def report(self):
        return {
            "prompt_tokens": self.total_prompt_tokens,
            "completion_tokens": self.total_completion_tokens,
            "total_tokens": self.total_prompt_tokens + self.total_completion_tokens,
        }

def track_token_usage(
    email: str,
    uri: str,
    usage: int,
    last_used_model: str | None = None,
    operation_type: str | None = None,
) -> int:
    """
    Track and persist token usage for a user.
    - Matches by `email` or `db_url`.
    - Increments daily, monthly and total usage.
    """
    try:
        normalized_email = (email or "").strip().lower() or None
        normalized_db_url = (uri or "").strip() or None
        logging.info(f"Tracking token usage for email: {normalized_email}, uri: {normalized_db_url}, usage: {usage}, operation_type: {operation_type}")
        is_neo4j_user = bool(normalized_email and normalized_email.endswith("@neo4j.com"))
        
        if operation_type == "precheck":
            limits = get_remaining_token_limits(email, uri)
            users_daily_limit = limits.get("daily_limit", 0)
            users_monthly_limit = limits.get("monthly_limit", 0)
            users_daily_used = limits.get("daily_used", 0)
            users_monthly_used = limits.get("monthly_used", 0)
            
            if get_value_from_env("LIMIT_TOKEN_USAGE_PER_USER", "False", bool):
                if ((users_daily_used > users_daily_limit) or (users_monthly_used > users_monthly_limit)) and not is_neo4j_user:
                    raise LLMGraphBuilderException(
                        "Token usage limit exceeded. Please contact the team to increase your limit."
                    )
            logging.info(
                "Precheck passed:  daily=%s/%s, monthly=%s/%s",
                users_daily_used, users_daily_limit, users_monthly_used, users_monthly_limit
            )
            return None
        
        if not normalized_email and not normalized_db_url:
            raise ValueError("Either email or db_url must be provided for token tracking.")

        token_uri = get_value_from_env("TOKEN_TRACKER_DB_URI")
        token_user = get_value_from_env("TOKEN_TRACKER_DB_USERNAME")
        token_password = get_value_from_env("TOKEN_TRACKER_DB_PASSWORD")
        token_database = get_value_from_env("TOKEN_TRACKER_DB_DATABASE", "neo4j")
        credentials = Neo4jCredentials(uri=token_uri, userName=token_user, password=token_password, database=token_database)
        if not all([token_uri, token_user, token_password]):
            raise EnvironmentError("Neo4j credentials are not set properly.")

        graph = create_graph_database_connection(credentials)
        daily_tokens_limit = get_value_from_env("DAILY_TOKENS_LIMIT", "250000", "int")
        monthly_tokens_limit = get_value_from_env("MONTHLY_TOKENS_LIMIT", "1000000", "int")
        auth_required = get_value_from_env("AUTHENTICATION_REQUIRED", False, bool)

        params = {
            "email": normalized_email,
            "db_url": normalized_db_url,
            "usage": usage,
            "lastUsedModel": last_used_model or "",
            "is_neo4j_user": is_neo4j_user,
            "daily_tokens_limit": daily_tokens_limit,
            "monthly_tokens_limit": monthly_tokens_limit,
            "operation_type": operation_type,
        }

        if auth_required:
            if not normalized_email:
                raise ValueError("Email is required for token tracking when authentication is required.")
            merge_query = """
            MERGE (u:User {email: $email})
            ON CREATE SET
                u.db_url = $db_url,
                u.is_neo4j_user = $is_neo4j_user,
                u.daily_tokens_limit = $daily_tokens_limit,
                u.monthly_tokens_limit = $monthly_tokens_limit,
                u.daily_tokens_used = $usage,
                u.monthly_tokens_used = $usage,
                u.total_tokens_used = $usage,
                u.lastUsedModel = $lastUsedModel,
                u.lastOperationUsage = $usage,
                u.createdAt = datetime(),
                u.updatedAt = datetime()
            ON MATCH SET
                u.db_url = coalesce(u.db_url, $db_url),
                u.updatedAt = datetime()
            RETURN u
            """
            result = graph.query(merge_query, params)
        else:
            if not normalized_db_url:
                raise ValueError("db_url is required for token tracking when authentication is not required.")
            params["email"] = "local_user"
            merge_query = """
            MERGE (u:User {db_url: $db_url})
            ON CREATE SET
                u.email = $email,
                u.is_neo4j_user = $is_neo4j_user,
                u.daily_tokens_limit = $daily_tokens_limit,
                u.monthly_tokens_limit = $monthly_tokens_limit,
                u.daily_tokens_used = $usage,
                u.monthly_tokens_used = $usage,
                u.total_tokens_used = $usage,
                u.lastUsedModel = $lastUsedModel,
                u.lastOperationUsage = $usage,
                u.createdAt = datetime(),
                u.updatedAt = datetime()
            ON MATCH SET
                u.updatedAt = datetime()
            RETURN u
            """
            result = graph.query(merge_query, params)

        if auth_required:
            update_query = """
            MATCH (u:User {email: $email})
            SET u.lastOperationUsage   = $usage,
                u.daily_tokens_used   = coalesce(u.daily_tokens_used, 0) + $usage,
                u.monthly_tokens_used = coalesce(u.monthly_tokens_used, 0) + $usage,
                u.total_tokens_used   = coalesce(u.total_tokens_used, 0) + $usage,
                u.lastUsedModel       = $lastUsedModel,
                u.is_neo4j_user       = $is_neo4j_user,
                u.updatedAt           = datetime(),
                u.files_processed     = CASE 
                    WHEN coalesce(u.files_processed, NULL) IS NULL AND $usage > 0 THEN 1
                    WHEN $operation_type = 'extraction' AND $usage > 0 THEN coalesce(u.files_processed, 0) + 1
                    ELSE u.files_processed END
            RETURN
                u.total_tokens_used    AS latestUsage,
                u.lastOperationUsage   AS lastOperationUsage,
                u.daily_tokens_used    AS daily_tokens_used,
                u.monthly_tokens_used  AS monthly_tokens_used,
                u.daily_tokens_limit   AS daily_tokens_limit,
                u.monthly_tokens_limit AS monthly_tokens_limit
            """
            result = graph.query(update_query, params)
        else:
            update_query = """
            MATCH (u:User {db_url: $db_url})
            SET u.lastOperationUsage   = $usage,
                u.daily_tokens_used   = coalesce(u.daily_tokens_used, 0) + $usage,
                u.monthly_tokens_used = coalesce(u.monthly_tokens_used, 0) + $usage,
                u.total_tokens_used   = coalesce(u.total_tokens_used, 0) + $usage,
                u.lastUsedModel       = $lastUsedModel,
                u.is_neo4j_user       = $is_neo4j_user,
                u.updatedAt           = datetime(),
                u.files_processed     = CASE 
                    WHEN coalesce(u.files_processed, NULL) IS NULL AND $usage > 0 THEN 1
                    WHEN $operation_type = 'extraction' AND $usage > 0 THEN coalesce(u.files_processed, 0) + 1
                    ELSE u.files_processed END
            RETURN
                u.total_tokens_used    AS latestUsage,
                u.lastOperationUsage   AS lastOperationUsage,
                u.daily_tokens_used    AS daily_tokens_used,
                u.monthly_tokens_used  AS monthly_tokens_used,
                u.daily_tokens_limit   AS daily_tokens_limit,
                u.monthly_tokens_limit AS monthly_tokens_limit
            """
            result = graph.query(update_query, params)
        if result and "latestUsage" in result[0]:
            daily_tokens_limit = result[0].get("daily_tokens_limit", 0)
            monthly_tokens_limit = result[0].get("monthly_tokens_limit", 0)
            daily_tokens_used = result[0].get("daily_tokens_used", 0)
            monthly_tokens_used = result[0].get("monthly_tokens_used", 0)
            logging.info("Token usage for user before limit check: daily_used=%s monthly_used=%s", daily_tokens_used, monthly_tokens_used)
            logging.info("Token limits for user: daily_limit=%s monthly_limit=%s", daily_tokens_limit, monthly_tokens_limit)
            logging.info("Is Neo4j user: %s", is_neo4j_user)
            if get_value_from_env("LIMIT_TOKEN_USAGE_PER_USER", "False", "bool"): 
                if ((daily_tokens_used > daily_tokens_limit) or (monthly_tokens_used > monthly_tokens_limit)) and not is_neo4j_user:
                    raise LLMGraphBuilderException(
                        "Token usage limit exceeded. Please contact the team to increase your limit."
                    )
            logging.info(
                "Updated token usage for user: "
                "latest=%s last_op=%s daily_used=%s monthly_used=%s",
                result[0]["latestUsage"],
                result[0].get("lastOperationUsage", 0),
                result[0].get("daily_tokens_used", 0),
                result[0].get("monthly_tokens_used", 0),
            )
            return result[0]["latestUsage"]

        logging.error("No matching User found or failed to fetch updated token usage. Result: %s", result)
        raise RuntimeError("User not found or failed to fetch updated token usage.")

    except Exception as e:
        logging.error(
            "Error in track_token_usage for identity %s: %s",
            email or uri,
            e,
            exc_info=True,
        )
        raise


def get_remaining_token_limits(email: str, uri: str) -> dict:
    """
    Returns the remaining daily and monthly token limits for a user, given email and/or uri.
    """
    try:
        normalized_email = (email or "").strip().lower() or None

        normalized_db_url = (uri or "").strip() or None
        logging.info(f"Fetching remaining token limits for email: {normalized_email}, uri: {normalized_db_url}")
        if not normalized_email and not normalized_db_url:
            raise ValueError("Either email or db_url must be provided for token tracking.")

        token_uri = get_value_from_env("TOKEN_TRACKER_DB_URI")
        token_user = get_value_from_env("TOKEN_TRACKER_DB_USERNAME")
        token_password = get_value_from_env("TOKEN_TRACKER_DB_PASSWORD")
        token_database = get_value_from_env("TOKEN_TRACKER_DB_DATABASE", "neo4j")
        if not all([token_uri, token_user, token_password]):
            raise EnvironmentError("Neo4j credentials are not set properly.")

        credentials = Neo4jCredentials(uri=token_uri, userName=token_user, password=token_password, database=token_database)
        graph = create_graph_database_connection(credentials)

        auth_required = get_value_from_env("AUTHENTICATION_REQUIRED", False, bool)
        user_node = None
        logging.info(f"Authentication required: {auth_required}")
        if auth_required:
            logging.info("Looking up user by email for token limits")
            if not normalized_email:
                raise ValueError("Email is required for token lookup when authentication is required.")
            result = graph.query(
                "MATCH (u:User {email: $email}) RETURN u", {"email": normalized_email}
            )
            logging.info(f"Query result for user lookup: {result}")
            if result and result[0].get("u"):
                user_node = result[0]["u"]
        else:
            logging.info("Looking up user by db_url for token limits")
            if not normalized_db_url:
                raise ValueError("db_url is required for token lookup when authentication is not required.")
            result = graph.query(
                "MATCH (u:User {db_url: $db_url}) RETURN u", {"db_url": normalized_db_url}
            )
            logging.info(f"Query result for user lookup: {result}")
            if result and result[0].get("u"):
                user_node = result[0]["u"]

        daily_tokens_limit = get_value_from_env("DAILY_TOKENS_LIMIT", "250000", "int")
        monthly_tokens_limit = get_value_from_env("MONTHLY_TOKENS_LIMIT", "1000000", "int")
        daily_tokens_used = 0
        monthly_tokens_used = 0
        if user_node:
            daily_tokens_limit = user_node.get("daily_tokens_limit", daily_tokens_limit)
            monthly_tokens_limit = user_node.get("monthly_tokens_limit", monthly_tokens_limit)
            daily_tokens_used = user_node.get("daily_tokens_used", 0)
            monthly_tokens_used = user_node.get("monthly_tokens_used", 0)


        return {
            "daily_remaining": max(daily_tokens_limit - daily_tokens_used, 0),
            "monthly_remaining": max(monthly_tokens_limit - monthly_tokens_used, 0),
            "daily_limit": daily_tokens_limit,
            "monthly_limit": monthly_tokens_limit,
            "daily_used": daily_tokens_used,
            "monthly_used": monthly_tokens_used,
        }
    except Exception as e:
        logging.error(
            "Error in get_remaining_token_limits for identity %s: %s",
            email or uri,
            e,
            exc_info=True,
        )
        raise

def get_user_embedding_model(email: str, uri: str) -> dict:
    """
    Retrieve the embedding provider and model for a user from the User node.
    If not found, return the local Ollama embedding defaults.
    """
    try:
        allow_embedding_change = False
        track_user_usage = get_value_from_env("TRACK_USER_USAGE", "false", bool)
        if not track_user_usage:
            embedding_provider = get_value_from_env("EMBEDDING_PROVIDER","ollama")
            embedding_model = get_value_from_env("EMBEDDING_MODEL","nomic-embed-text")
            if not embedding_provider or not embedding_model:
                raise EnvironmentError("EMBEDDING_PROVIDER and EMBEDDING_MODEL environment variables must be set")
            _, embedding_dimension = load_embedding_model(embedding_provider, embedding_model)
            return embedding_provider, embedding_model, embedding_dimension, allow_embedding_change
        else:
            token_uri = get_value_from_env("TOKEN_TRACKER_DB_URI")
            token_user = get_value_from_env("TOKEN_TRACKER_DB_USERNAME")
            token_password = get_value_from_env("TOKEN_TRACKER_DB_PASSWORD")
            token_database = get_value_from_env("TOKEN_TRACKER_DB_DATABASE", "neo4j")
            if not all([token_uri, token_user, token_password]):
                allow_embedding_change = False        
                raise EnvironmentError("Neo4j credentials are not set properly.")
            
        allow_embedding_change = True
        normalized_email = (email or "").strip().lower() or None
        normalized_db_url = (uri or "").strip() or None
        if not normalized_email and not normalized_db_url:
            raise ValueError("Either email or db_url must be provided for fetching embedding model.")

        credentials = Neo4jCredentials(uri=token_uri, userName=token_user, password=token_password, database=token_database)
        graph = create_graph_database_connection(credentials)

        auth_required = get_value_from_env("AUTHENTICATION_REQUIRED", False, bool)
        user_node = None
        if auth_required:
            result = graph.query(
                "MATCH (u:User {email: $email}) RETURN u", {"email": normalized_email}
            )
            if result and result[0].get("u"):
                user_node = result[0]["u"]
        else:
            result = graph.query(
                "MATCH (u:User {db_url: $db_url}) RETURN u", {"db_url": normalized_db_url}
            )
            if result and result[0].get("u"):
                user_node = result[0]["u"]

        if user_node:
            embedding_provider = user_node.get("embedding_provider")
            embedding_model = user_node.get("embedding_model")
            embedding_dimension = user_node.get("embedding_dimension")
            if embedding_provider and embedding_model and embedding_dimension is not None:
                return embedding_provider, embedding_model, embedding_dimension, allow_embedding_change

        return "ollama", "nomic-embed-text", 768, allow_embedding_change
    except Exception as e:
        logging.error(f"Error in get_user_embedding_model for email {email}: {e}")
        return "ollama", "nomic-embed-text", 768, allow_embedding_change

def change_user_embedding_model(email:str, uri:str, new_embedding_provider: str, new_embedding_model: str) -> dict:
    """
    Update the User node's embedding_provider and embedding_model properties.
    If the embedding dimension changes, drop the vector index in the connected DB.
    Args:
        email (str): User's email
        uri (str): URI of the connected DB (not the token tracker DB)
        new_embedding_provider (str): New embedding provider
        new_embedding_model (str): New embedding model
    Returns:
        dict: with status, message and other details.
    """
    try:
        normalized_email = (email or "").strip().lower() or None
        normalized_db_url = (uri or "").strip() or None
        if not normalized_email and not normalized_db_url:
            raise ValueError("Either email or db_url must be provided for changing embedding model.")

        token_uri = get_value_from_env("TOKEN_TRACKER_DB_URI")
        token_user = get_value_from_env("TOKEN_TRACKER_DB_USERNAME")
        token_password = get_value_from_env("TOKEN_TRACKER_DB_PASSWORD")
        token_database = get_value_from_env("TOKEN_TRACKER_DB_DATABASE", "neo4j")
        if not all([token_uri, token_user, token_password]):
            return {"status": "Failed", "message": "Token tracker DB credentials are not set properly."}

        tracker_credentials = Neo4jCredentials(uri=token_uri, userName=token_user, password=token_password, database=token_database)
        tracker_graph = create_graph_database_connection(tracker_credentials)

        auth_required = get_value_from_env("AUTHENTICATION_REQUIRED", False, bool)
        user_node = None
        result = None
        if auth_required:
            if not normalized_email:
                return {"status": "Failed", "message": "Email is required to update embedding model when authentication is required."}
            result = tracker_graph.query(
                "MATCH (u:User {email: $email}) RETURN u", {"email": normalized_email}
            )
        else:
            if not normalized_db_url:
                return {"status": "Failed", "message": "db_url is required to update embedding model when authentication is not required."}
            result = tracker_graph.query(
                "MATCH (u:User {db_url: $db_url}) RETURN u", {"db_url": normalized_db_url}
            )
        if result and result[0].get("u"):
            user_node = result[0]["u"]
            
        old_dimension = user_node.get("embedding_dimension") if user_node else 384
        _, new_dimension = load_embedding_model(new_embedding_provider, new_embedding_model)
        if auth_required:
            update_query = """
            MATCH (u:User {email: $email})
            SET u.embedding_provider = $embedding_provider, u.embedding_model = $embedding_model, u.embedding_dimension = $embedding_dimension, u.updatedAt = datetime()
            RETURN u
            """
            tracker_graph.query(update_query, {"email": normalized_email, "embedding_provider": new_embedding_provider, "embedding_model": new_embedding_model, "embedding_dimension": new_dimension})
        else:
            update_query = """
            MATCH (u:User {db_url: $db_url})
            SET u.embedding_provider = $embedding_provider, u.embedding_model = $embedding_model, u.embedding_dimension = $embedding_dimension, u.updatedAt = datetime()
            RETURN u
            """
            tracker_graph.query(update_query, {"db_url": normalized_db_url, "embedding_provider": new_embedding_provider, "embedding_model": new_embedding_model, "embedding_dimension": new_dimension})
        
        change_index = False
        if old_dimension != new_dimension:
            change_index = True
        return {
            "status": "Success",
            "change_index": change_index, 
            "new_embedding_provider": new_embedding_provider, 
            "new_embedding_model": new_embedding_model, 
            "new_dimension": new_dimension
        }
    except Exception as e:
        logging.error(f"Error in change_user_embedding_model for email {email}: {e}")
        return {"status": "Failed", "message": str(e)}
    