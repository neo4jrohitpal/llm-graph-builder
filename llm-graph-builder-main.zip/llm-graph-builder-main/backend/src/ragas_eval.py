import os
import logging
import time
from src.llm import get_llm
from datasets import Dataset
from ragas import evaluate
from ragas.metrics import answer_relevancy, faithfulness,context_entity_recall
from src.shared.common_fn import load_embedding_model 
from ragas.dataset_schema import SingleTurnSample
from ragas.metrics import RougeScore, SemanticSimilarity
from ragas.llms import LangchainLLMWrapper
from ragas.embeddings import LangchainEmbeddingsWrapper
import nltk

nltk.data.path.append("/usr/local/nltk_data")
nltk.data.path.append(os.path.expanduser("~/.nltk_data"))
try:
    nltk.data.find("tokenizers/punkt")
except LookupError:
    nltk.download("punkt", download_dir=os.path.expanduser("~/.nltk_data"))
    

def get_ragas_metrics(question: str, context: list, answer: list, model: str, embedding_provider: str, embedding_model: str):
    """Calculates RAGAS metrics."""
    try:
        start_time = time.time()
        dataset = Dataset.from_dict(
            {"question": [question] * len(answer),"reference": answer, "answer": answer, "contexts": [[ctx] for ctx in context]}
        )
        logging.info("Evaluation dataset created successfully.")
        if ("diffbot" in model) or ("ollama" in model):
            raise ValueError(f"Unsupported model for evaluation: {model}")
        else:
            llm, model_name, _ = get_llm(model=model)
            llm = LangchainLLMWrapper(llm)
    
        logging.info(f"Evaluating with model: {model_name}")
        EMBEDDING_FUNCTION, _ = load_embedding_model(embedding_provider, embedding_model)
        score = evaluate(
            dataset=dataset,
            metrics=[faithfulness, answer_relevancy,context_entity_recall],
            llm=llm,
            embeddings=EMBEDDING_FUNCTION,
        )
        
        score_dict = (
            score.to_pandas()[["faithfulness", "answer_relevancy","context_entity_recall"]]
            .fillna(0)
            .round(4)
            .to_dict(orient="list")
        ) 
        end_time = time.time()
        logging.info(f"Evaluation completed in: {end_time - start_time:.2f} seconds")
        return score_dict
    except ValueError as e:
       if "Unsupported model for evaluation" in str(e):
           logging.error(f"Unsupported model error: {e}")
           return {"error": str(e)} 
       logging.exception(f"ValueError during metrics evaluation: {e}")
       return {"error": str(e)}
    except Exception as e:
       logging.exception(f"Error during metrics evaluation: {e}")
       return {"error": str(e)}


async def get_additional_metrics(question: str, contexts: list, answers: list, reference: str, model_name: str, embedding_provider: str, embedding_model: str):
   """Calculates multiple metrics for given question, answers, contexts, and reference."""
   try:
       if ("diffbot" in model_name) or ("ollama" in model_name):
           raise ValueError(f"Unsupported model for evaluation: {model_name}")
       llm, model_name, _ = get_llm(model=model_name)
       embeddings, _ = load_embedding_model(embedding_provider, embedding_model)
       embedding_model = LangchainEmbeddingsWrapper(embeddings=embeddings)
       rouge_scorer = RougeScore()
       semantic_scorer = SemanticSimilarity()
       semantic_scorer.embeddings = embedding_model
       metrics = []
       for response, context in zip(answers, contexts):
           sample = SingleTurnSample(response=response, reference=reference)
           rouge_score = await rouge_scorer.single_turn_ascore(sample)
           rouge_score = round(rouge_score,4)
           semantic_score = await semantic_scorer.single_turn_ascore(sample)
           semantic_score = round(semantic_score, 4)
           metrics.append({
               "rouge_score": rouge_score,
               "semantic_score": semantic_score,
           })
       return metrics
   except Exception as e:
       logging.exception("Error in get_additional_metrics")
       return {"error": str(e)}