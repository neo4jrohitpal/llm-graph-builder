import logging

from src.shared.common_fn import get_value_from_env

class CustomLogger:
    def __init__(self):
        self.is_gcp_log_enabled = get_value_from_env("GCP_LOG_METRICS_ENABLED", "False", "bool")
        if self.is_gcp_log_enabled:
            logging.warning(
                "GCP_LOG_METRICS_ENABLED is ignored in the local Ollama build."
            )
            self.is_gcp_log_enabled = False
            self.logger = None
        else:
            self.logger = None

    def log_struct(self, message, severity="DEFAULT"):
        if self.is_gcp_log_enabled and message is not None:
            self.logger.log_struct({"message": message, "severity": severity})
        else:
            logging.log(
                getattr(logging, severity.upper(), logging.INFO),
                "%s",
                message,
            )
