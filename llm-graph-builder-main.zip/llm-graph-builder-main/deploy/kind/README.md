# CPU-only Kind lab deployment

This deploys only llm-graph-builder. It uses the existing services:

- Neo4j: `my-cluster-lb-neo4j.neo4j.svc.cluster.local:7687`
- Ollama: `ollama-service.ollama.svc.cluster.local:11434`

## 1. Build and load the images

Run from the repository root:

```powershell
docker build -t llm-graph-builder-backend:lab .\backend
docker build --build-arg VITE_BACKEND_API_URL=/api --build-arg VITE_LLM_MODELS=ollama_llama3 --build-arg VITE_LLM_MODELS_PROD=ollama_llama3 -t llm-graph-builder-frontend:lab .\frontend

kind get clusters
kind load docker-image llm-graph-builder-backend:lab llm-graph-builder-frontend:lab --name <kind-cluster-name>
```

## 2. Ensure the Ollama models exist

Find the Ollama pod, then pull both models in that pod:

```powershell
kubectl get pods -n ollama
kubectl exec -n ollama <ollama-pod-name> -- ollama pull llama3
kubectl exec -n ollama <ollama-pod-name> -- ollama pull nomic-embed-text
```

The manifest expects the chat model name `llama3`. If the installed model uses
another tag, update `LLM_MODEL_CONFIG_OLLAMA_LLAMA3` in the ConfigMap before
applying it.

## 3. Create the application credential Secret

Kubernetes does not allow a pod to reference `neo4j-auth` from another
namespace. Create an app-local Secret using the same Neo4j credentials:

```powershell
kubectl create namespace llm-graph-builder --dry-run=client -o yaml | kubectl apply -f -
kubectl create secret generic llm-graph-builder-neo4j `
  --namespace llm-graph-builder `
  --from-literal=NEO4J_USERNAME='neo4j' `
  --from-literal=NEO4J_PASSWORD='<neo4j-password>' `
  --dry-run=client -o yaml | kubectl apply -f -
```

Do not commit the password or a generated Secret manifest.

## 4. Deploy and verify

```powershell
kubectl apply -f .\deploy\kind\llm-graph-builder.yaml
kubectl rollout status deployment/llm-graph-builder-backend -n llm-graph-builder
kubectl rollout status deployment/llm-graph-builder-frontend -n llm-graph-builder
kubectl get pods -n llm-graph-builder
kubectl port-forward -n llm-graph-builder service/llm-graph-builder-frontend 8080:8080
```

Open `http://localhost:8080`.

If the UI asks for Neo4j connection details, use:

- URI: `bolt://my-cluster-lb-neo4j.neo4j.svc.cluster.local:7687`
- Database: `neo4j`
- The same username and password used in the Secret

## Embedding migration

`nomic-embed-text` creates 768-dimensional vectors. Existing MiniLM vectors
are 384-dimensional, so remove the old vector indexes/data and re-ingest lab
documents before using vector chat.
