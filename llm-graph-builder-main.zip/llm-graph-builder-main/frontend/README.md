# Neo4j Knowledge Graph Builder

ReactJS app for building an knowledge graph using [Neo4j Needle](https://www.neo4j.design/).
    
## Features
- 🚀 Responsive: Adapts to different screen sizes for optimal user experience.
- ⚙️ Neo4j Integration: A simple example for connecting to a Neo4j database.
- 🔐 Neo4j Auto-connect: Automatically connects to the Neo4j database if the user has a session saved (using localStorage).
- 💻 Dropzone: To drop pdf or txt files.
- 💻 Table : To show uploaded files and generate knowledge graph.
- 🛠️️ Modular approach: Facilitates easy customization.


## Installation:
```shell
npm install -g yarn
yarn i
yarn run dev
```

##
Do run yarn add -- package name to get project updated with required dependencies.

29/01/2024> Latest dependency
yarn add uuid 
##
Upload api url should be picked from: ports tab under codespace environment // For demo
## What it looks like
